library(shiny)
library(googleway)
library(shinyWidgets)

key <- "MyKey"
set_key(key = key)
google_keys()


#ui

shinyUI(fluidPage(
  
#head panel
  
  headerPanel("San Francisco Food Safety Inspection"),
  
#set up the backgrond color
  
  setBackgroundColor(
    color = c("#03BCC0"),
    gradient = "linear",
    direction = "bottom"
  ),


  
  #setting SidebarLayout
  sidebarLayout(
    
   sidebarPanel(

 #############################################################
 # create user location input (draft)
     
     #div(
      
    # textInput(inputId = "my_address", label = "Please input the location")    
       #,textOutput(outputId = "copy_of_address")
      # ,HTML(paste0("
        # <script>
        #  function initAutocomplete() {
         #  new google.maps.places.Autocomplete(
        #(document.getElementById('my_address')),
        # {types: ['geocode']}
        #);
        #  }
       # </script>
      # <script src='https://maps.googleapis.com/maps/api/js?key=", key,"&libraries=places&callback=initAutocomplete'
     #  async defer></script>
  # "))
   # ,google_mapOutput(outputId = "my_map")
  #),
 ##################################################
    selectInput("BusinessName", "BusinessAddress", c("", data_high$business_name), selected=""
  ),
 
     ########################################################################################### 33333333333333333
    
  #Creat the text description of the progrom

      tags$h4("SF Food Safty Program"),
      tags$p("San Francisco is famous for its restaurants and food trends. Along with its iconic Golden Gate Bridge, scenic streets, and booming culture, one of it’s main attraction is food. Often times, important housekeeping things may be overlooked in the food industry in the fast paced modern culture. To keep the food quality healthy and safe and to keep the restaurants and food handlers accountable, the Health Department has developed an inspection report and scoring system. These inspections may be unscheduled or planned. After an inspection of the facility, the Health Inspector calculates a score based on the violations observed.In order to implement the food safety ordinance, the Health Department has developed an inspection report and inspection scoring system. After conducting an inspection of a food facility, the Health Inspector will calculate a score based on the violations observed. Restaurant health inspection has been suggested (Koeune, Schroth, Holmes, & Helmstetter, 2000; Lueck & MacFarquhar, 2000) to be published to increase public awareness of food by the health department. For more information on food safety scores and interpretation of the scores, check the link below."),
      tags$a(href = "https://www.sfdph.org/dph/EH/Food/Inspections.asp","Click for More Information"),
      tags$img(height=150,
               width = 280,
               src="https://cdn.kaplaninternational.com/sites/default/files/styles/1170_x_auto/public/school-hero-us-san-francisco.jpg?itok=963VO_aS"
               
      )
      
     ########################################################################################### 
     
   ),
    
   ########################################################################################### 
   #main panel
    
    mainPanel(
      tags$h4("San Fransico Food Safety Inspection Map"),
      textOutput("text1"),
  
        
      tags$br(),
     leafletOutput("leaflet1"),
     tags$br(),
   

     tags$h4("San Fransico Score Distribution Veg Restaurant VS None-Vge Restaurant"),
     textOutput("text2"),
     tags$br(),
    plotlyOutput("plot5"),
    tags$br(),
    tags$h4("San Fransico Restaurant Score Distribution by Risk Category"),
   textOutput("text3"),
   tags$br(),
    plotlyOutput("plot6"),
    tags$br(),
   tags$h4("San Fransico Restaurant Violation Change by Time"),
   textOutput("text5"),
   tags$br(),
    plotlyOutput("plot7"),
   tags$br(),
 


    
      
      
    )
    
    
    
  )
  
  
  
)


)

