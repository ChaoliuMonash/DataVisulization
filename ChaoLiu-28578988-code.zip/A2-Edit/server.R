
#please load this library when the first time running the app
library(shiny)
library(plotly)
library(googleway)
library(leaflet)
library(dplyr)
library("readxl")



#please read the data when the first time running the app
my_data <- read_excel("Clean Version.xlsx")



#please read the data when the first time running the app, filter the high score data
data_high<- my_data[which(my_data$inspection_score > 90 ),]

#please read the data when the first time running the app,ording data.
data_high<- data_high[order(data_high$inspection_score, data_high$risk_category),]



#convert the  values & position(lat & long) values into numeric,please run this when the first time running the app


data_high$business_latitude = as.numeric(sub("%","",data_high$business_latitude))
data_high$business_longitude = as.numeric(sub("%","",data_high$business_longitude))

#creat the shiny function 

shinyServer(function(input,output)
{

  
##############################################################
  #Creat the Green leaf Icon for the leaft map
  greenLeafIcon <- makeIcon(
    iconUrl = "http://leafletjs.com/examples/custom-icons/leaf-green.png",
    iconWidth = 38, iconHeight = 95,
    iconAnchorX = 22, iconAnchorY = 94,
    shadowUrl = "http://leafletjs.com/examples/custom-icons/leaf-shadow.png",
    shadowWidth = 50, shadowHeight = 64,
    shadowAnchorX = 4, shadowAnchorY = 62
  )
  
  
  ##############################################
  #Creat the text for the descriptions
  
  output$text1 <- renderText({
    " SF Inspection Map shows all of high food safty score restaurants, all of the restaurants on the map recieved inspections Score above 90."
  })
  
  
  
  output$text5 <- renderText({
    " SF Inspection Vge Restaurants Map shows all of  Vegan restaurants in San Fransisco."
  })
  
  
  
  output$text2 <- renderText({  
    "The restaurant type refers to the restaurant type which includes the vegan and none vegan restaurant. This plot shows the comparison of vegan and none vegan inspection results change by time(double click the legend to filter the result).Compare with normal restaurants, more than half of the vegan restaurant inspection score distributes between higher 80 to lower 90 which indicates the good food safety. Also, there is no vegan restaurants was found poor food safety issues. Therefore, if someone wants to eat outside, vegan restaurants can be a relatively safe choice."
  })

  
  output$text3 <- renderText({  
    "This plot shows the comparison of different risk categories changing by time (double click the legend to filter the result, around 30% of the high-risk violations were recorded in the high inspection score restaurants (80-90), which means the high inspection score result does not mean the restaurant is 100% safty to public health."
  })
  output$text4 <- renderText({  
    "San Francisco Healthy Inspection Risk Category"
  })
  
  
  output$text5 <- renderText({  
    "San Francisco Violation Description shows the violation of the local restaurant distribution change  by the time. In 2017, most restaurants were found violated the restrictions related to facilities like improper or defective plumbing, unclean or degraded floors walls, or ceilings. The most common food-related violation is unclean nonfood contains. In 2018 and 2019, the most common issue the restaurant was found is improper thawing methods. This finding is disturbing as improper thawing food may pose a food safety risk. According to the food safety supervisor, it allows food poisoning bacteria to grow if the temperature of the food is between 5°Cand 60°C during thawing (CTA Training Specialists, August, 2012)."
  })
  
  
  
  
  #########################################################################
  
  #creat the Leaflet Map 
  #https://waterdata.usgs.gov/blog/inlmiscmaps/
  
  #########################################################################
  
  output$leaflet1 = renderLeaflet({
    
    map=leaflet(data = data_high) %>% addTiles() %>%
      addMarkers(
        ~business_longitude, 
        ~business_latitude, 
        icon = greenLeafIcon,
        #popup = ~as.character(inspection_score),
        
      # city <- rgdal::readOGR(system.file("https://data.sfgov.org/api/views/yqxu-izzm/rows.json?accessType=DOWNLOAD", package = "inlmisc")[1]),
        
        
        popup=paste(
          "Business Name:", data_high$business_name, "<br>",
          "Business Adress:", data_high$business_address, "<br>",
          "Restaurant Type:", data_high$Type, "<br>",
          "Inspection Score:", data_high$inspection_score,"<br>",
            "Risk Level:", data_high$risk_category),
        clusterOptions = markerClusterOptions(),
        
        group="marker"
 )
    
    map <- inlmisc::AddHomeButton(map)
   # map=inlmisc::AddSearchButton(map, group = "marker", zoom = 15,
                             #    textPlaceholder = "Search location here")
  
    

  })
    

#############################################################################3
  
#Creat the the interactive plot for the risk category distribution 
 
    output$plot3=renderPlot({
      ggplot(my_data, 
             aes(x = inspection, 
                 fill = risk_category)) + 
        geom_bar(position = position_dodge(preserve = "single"))
      
      
      
    })
  
###########################################################################


  #Plot5: Creat the veg and none vge restaurant distribution plot.

    output$plot5 <- renderPlotly({
      plot_ly(my_data, x = ~inspection_date, y=~inspection_score, color =~Type, type="scatter", mode = "point") %>%
        layout(title = "Vegan Restaurant vs Non-Vegan Restaurant Inspection Score Comparation",
               xaxis = list(title = "Year"),
               yaxis = list(range = c(50,100), title ="Inspection score Change by Time" ))
    })
    
    
  ################################################################
  #Plot6: Creat risk category distribution plot.
  
    output$plot6 <- renderPlotly({
      plot_ly(my_data, x = ~inspection_date, y=~inspection_score, color =~my_data$risk_category, type="scatter", mode = "line") %>%
        layout(title = "Risk Category Change by Time",
               xaxis = list(title = "Year"),
               yaxis = list(range = c(50,100), title ="Inspection Score" ))
    })
    
   ##################################################################
  #Plot7: Creat the violation descrition distribution by time.
    
    output$plot7 <- renderPlotly({
    
   
    fig <- plot_ly()
    
    fig <- plot_ly(my_data, x = ~inspection_date, y = ~inspection_score, text = ~violation_description, type = 'scatter', mode = 'markers',
                   marker = list(color = ~inspection_score, opacity = 2))
    fig <- fig %>% layout(title = 'Violation Description Distribution by Time ',
                          xaxis = list(showgrid = FALSE),
                          yaxis = list(showgrid = FALSE))
    
    fig
    
    
    })
  
  
  ###########################################################33333333333333
  #creat the searching address function 
  my_address <- reactive({
   input$my_address
  })
  
  output$copy_of_address <- renderText({
   my_address()
  })
  
  output$my_map <- renderGoogle_map({
    my_address <- my_address()
    validate(
    need(my_address, "Address not available")
   )
    
   df <- google_geocode(address = my_address)
    my_coords <- geocode_coordinates(df)
 my_coords <- c(my_coords$lat[1], my_coords$lng[1])
    
   google_map(
    location = my_coords,
  zoom = 12,
    map_type_control = FALSE,
     zoom_control = FALSE,
     street_view_control = FALSE
   )

  #############################################################################3

   
  
  })  

})

               
    
    

  
 
  
  

